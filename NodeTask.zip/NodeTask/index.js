'use strict';

const http = require('http');
var url = require('url')
var mongoUrl = "mongodb://localhost:27017/";
const qs = require('querystring');
const Enigma=require('./enigma');
const eng= new Enigma('Magrethea');

var MongoClient = require('mongodb').MongoClient;




let routes={
                'GET':{
                    '/getAllUsers':(req,res)=>{},


                    '/getUser/{id}':(req,res)=>{}


                       },
                'POST':{
                    
                        '/login':(req,res)=>{

                        },

                       
                         '/register':(req,res)=>{
                          
                            let body='';
                        req.on('data', data=>{
                            body+=data;
                        });
                           
                        req.on('end', ()=>{
                               
                                let params=qs.parse(body);

                                MongoClient.connect(mongoUrl,{ useNewUrlParser: true }, function(err, db) {
                                    if (err) {
                                        console.log("error", err);
                                    } else
                                     {
                                        var dbo = db.db('employee');
                                        var pass=params['password'];
                                        let encodeString=eng.encode(pass);


                                        var myobj = { firstName: params['firstName'], lastName: params['lastName'], email:params['email'],password: encodeString, address: params['address'], };
                                        dbo.collection("customers").insertOne(myobj, function(err, res) {
                                                      if (err) throw err;
                                                      console.log("1 document inserted");
                                                      db.close();
                                                    });
                                     }
                                });
                            });
                            }
                        },

                'PUT':{
                    '/updateUser/{id}':(req,res)=>{}
                     },

                     'NA':(req,res)=>{
                    res.writeHead(404);
                    res.end('URL not found...!');
                                 }   
                
                
                }
function router(req, res){
    let baseURI =url.parse(req.url,true);
   
    
    let resolveRoute=routes[req.method][baseURI.pathname];
if(resolveRoute!=undefined)
{
    req.queryParams=baseURI.query;
    resolveRoute(req,res);
}else
{
    routes['NA'](req,res);
}
}


http.createServer(router).listen(3000, ()=>{
    console.log("Server is Running");
});