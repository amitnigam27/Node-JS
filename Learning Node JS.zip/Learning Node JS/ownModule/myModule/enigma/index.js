'use strict';

/*exports.hello=(user)=>{
    return "Hello " + user;
}

exports.goodMorning=(user)=>{
    return "Good Morning " + user;
}
*/
const qr=require('qr-image');
const fs=require('fs');

const crypto=require('crypto');
module.exports=function(key){
    this.key=key;
    return {
       /* hello:(user)=>{
            return "Hello " +user;
        },
        goodMorning: (user)=>{
            return "Good Morning " +user;
        }*/

        encode:(str)=> {
            let encoder=crypto.createCipher('aes-256-ctr', this.key);
            return encoder.update(str , 'utf-8', 'hex');
        },

        decode: (str)=> {
            let decoder=crypto.createDecipher('aes-256-ctr', this.key);
            return decoder.update(str , 'hex', 'utf-8');
        },
        qrgen:(data, file)=>{
            let dataToEncode=data|| null;
            let outImage=file||null;
            if(dataToEncode!==null && outImage!==null)
            {
                qr.image(dataToEncode, {
                    type:'png',
                    size:20
                }).pipe(fs.createWriteStream(outImage));
                return true;
            }
            else{
                return false;
            }
        }


    }    
}