'use strict';

const Enigma=require('./enigma');

const eng= new Enigma('Magrethea');

//console.log(eng.hello("Amit"));
//console.log(eng.goodMorning("Amit"));


let encodeString=eng.encode("Don't Panic!");
let decodeString=eng.decode(encodeString);

console.log("Encoded:", encodeString);
console.log("Decoded:", decodeString);

let qr=eng.qrgen("https://www.npmjs.com", "outImage.png");

qr ? console.log("QR Code Created!") : console.log('QR Code Failed');